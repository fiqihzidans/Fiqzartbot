W4N4B5 - JS (Anti - JS - Club)

How to run ?
------
- `git clone https://gitlab.com/TeamNoobBot/WanabeJS.git`
- `cd WanabeJS && npm install`
- `npm start`



Error? Pm Me
------
https://line.me/ti/p/~agatis2



[TEAM NOOB BOT] Anda diundang untuk bergabung dengan sebuah Square LINE.
------
https://line.me/ti/g2/PEBDM2HEY5
Bot Programing...  TCR, VODKA, ALPHAT
------